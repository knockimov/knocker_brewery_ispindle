# Compile from Sources

Platform.io is used to build.
Install platformio core and run `pio run` inside the pio folder.